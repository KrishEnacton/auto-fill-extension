(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-f4fac2d8.js")
    );
  })().catch(console.error);

})();
