(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-7c4229eb.js")
    );
  })().catch(console.error);

})();
