(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-a1ce4652.js")
    );
  })().catch(console.error);

})();
